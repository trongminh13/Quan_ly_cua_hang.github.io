/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objects;

import QuanLy.*;
import java.util.List;
import FileIOCSV.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class testObject {

//    public static void main(String[] args) {
//        FileIOSanPham fileIOSanPham = new FileIOSanPham();
//        QuanLySanPham quanLySanPham = new QuanLySanPham();
////
//        SanPham s1 = new SanPham("Snack banh gao cay han quoc", "Haitai - Han quoc", "banh keo", 1000, "goi", 35000, LocalDate.parse("02/08/2021", DateTimeFormatter.ofPattern("dd/MM/yyyy")), LocalDate.parse("02/08/2022", DateTimeFormatter.ofPattern("dd/MM/yyyy")));
//        s1.setGiaBan(s1.getGiaNhap());
//        SanPham s2 = new SanPham("Dau goi cafe co cay hoa la 300g", "Wellness", "dau goi", 500, "chai", 187000, LocalDate.parse("05/06/2021", DateTimeFormatter.ofPattern("dd/MM/yyyy")), LocalDate.parse("05/06/2022", DateTimeFormatter.ofPattern("dd/MM/yyyy")));
//        s2.setGiaBan(s2.getGiaNhap());
//        quanLySanPham.ThemSP(s1);
//        quanLySanPham.ThemSP(s2);
//        List<SanPham> listSanPhams = fileIOSanPham.SanPhamReadCSV();
//        for (SanPham s : listSanPhams) {
//            System.out.println(s.toString());
//        }
//        
//        while (!listSanPhams.isEmpty()) {
//            listSanPhams.remove(0);
//        }
//        fileIOSanPham.SanPhamWriteToCSV(listSanPhams);
//        List<HoaDon> listHoaDons = new ArrayList<>();
//        HoaDonBanHang hdbh = new HoaDonBanHang();
//        listHoaDons.add(hdbh);
//    }
}
